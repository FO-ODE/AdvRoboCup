^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tts
^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.4 (2023-05-05)
------------------
* Merge branch 'fix_tutorials_noetic' into 'noetic-devel'
  Fix tutorials noetic
  See merge request apps/tiago_tutorials!38
* Fix Qt and opencv version errors + update package.xml
* Contributors: narcismiguel, thomaspeyrucain

2.0.3 (2020-01-28)
------------------

2.0.2 (2018-11-16)
------------------

2.0.1 (2018-04-20)
------------------

2.0.0 (2018-03-20)
------------------
* Homogenize package versions
* Merge branch 'correct-tts-opencv-demo-motions-Readme' into 'master'
  Corrected tts opencv demo motions readme
  See merge request !9
* corrected syntax readme files opencv, demo motions and tts
* corrected syntax readme files opencv, demo motions and tts
* corrected syntax readme files opencv, demo motions and tts
* Merge branch 'add-tts' into 'master'
  Add tts
  See merge request !5
* added argument to launch file to choose between terminal and gui, assigned lang_id, added feedback and result to terminal client.
* cleaned code and added copyright
* added readme file, changed the name of the launch file and added an argument to the launch file to allow switching between the terminal and gui versions of the code
* fixed syntax error
* created gui, new py script, action server gives feedback and result
* First rendition
* Added catkin package for tts
* Contributors: Job van Dieten, Jordi Pages, Victor Lopez, job-1994

0.0.1 (2015-08-03)
------------------
