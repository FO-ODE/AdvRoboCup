^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package play_with_sensors
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.4 (2023-05-05)
------------------
* Merge branch 'fix_tutorials_noetic' into 'noetic-devel'
  Fix tutorials noetic
  See merge request apps/tiago_tutorials!38
* Fix Qt and opencv version errors + update package.xml
* Contributors: narcismiguel, thomaspeyrucain

2.0.3 (2020-01-28)
------------------

2.0.2 (2018-11-16)
------------------

2.0.1 (2018-04-20)
------------------

2.0.0 (2018-03-20)
------------------
* Homogenize package versions
* Fix type of depth topic to make the demo work
* Removed autocompletion trick that made node not work
* Fix for #13762 (hopefully)
* Merge branch 'more_tutorials' into 'master'
  More tutorials
  Added many more tutorials
  See merge request !1
* Added examples of using sensors data from python
* Contributors: Sam Pfeiffer, Victor Lopez

0.0.1 (2015-08-03)
------------------
