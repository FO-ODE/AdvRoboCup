^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tiago_pick_demo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.4 (2023-05-05)
------------------
* Merge branch 'fix_tutorials_noetic' into 'noetic-devel'
  Fix tutorials noetic
  See merge request apps/tiago_tutorials!38
* Fix tiago_pick_demo
* Contributors: narcismiguel, thomaspeyrucain

2.0.3 (2020-01-28)
------------------

2.0.2 (2018-11-16)
------------------
* Forward recording argument
* Contributors: Victor Lopez

2.0.1 (2018-04-20)
------------------

2.0.0 (2018-03-20)
------------------
* Homogenize package versions
* Provide the possibility of disabling rviz and gzclient
* Add moveit_commander dependency
* migrate to tf2
* Merge branch 'fix-pick-service' into 'master'
  Fix pick_gui service returning error
  See merge request !12
* Fix pick_gui service returning error
* add cylinder detector example
* Fix genjava build problem
  There was a build problem that occurred when genjava is installed. Adding the missing build_depend to message_generation fixes this.
* Merge pull request #2 from sebastianstock/patch-2
  Fix genjava build problem by adding message_generation
* Fix genjava build problem
  There was a build problem that occurred when genjava is installed. Adding the missing build_depend to message_generation fixes this.
* fix identation
* remove any object attached to the gripper
* add wait_for_server for play_motion
* Merge branch 'add-pick-demo' into 'master'
  initial commit of the tiago pick & place demo
  See merge request !11
* initial commit of the demo
* Contributors: David Fernandez, Jordi Pages, Sebastian Stock, Victor Lopez

0.0.1 (2015-08-03)
------------------
