^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tiago_aruco_demo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.4 (2023-05-05)
------------------
* Merge branch 'fix_tutorials_noetic' into 'noetic-devel'
  Fix tutorials noetic
  See merge request apps/tiago_tutorials!38
* Minor fix + rosinstall fix
* Merge branch 'aruco_demo_fix' into 'erbium-devel'
  Aruco demo fix
  See merge request apps/tiago_tutorials!30
* Add look to point demo to the launch file
* Change rviz file name
* Add rviz to show the result of the ArUco marker detection demo
* Contributors: ThomasPeyrucain, narcismiguel, thomaspeyrucain, victor

2.0.3 (2020-01-28)
------------------

2.0.2 (2018-11-16)
------------------

2.0.1 (2018-04-20)
------------------

2.0.0 (2018-03-20)
------------------
* Homogenize package versions
* add aruco demo
* Contributors: Jordi Pages, Victor Lopez

0.0.1 (2015-08-03)
------------------
