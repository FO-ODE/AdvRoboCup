^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tiago_pcl_tutorial
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.4 (2023-05-05)
------------------
* Merge branch 'fix_tutorials_noetic' into 'noetic-devel'
  Fix tutorials noetic
  See merge request apps/tiago_tutorials!38
* Minor fix + rosinstall fix
* Split look_down into torso_up and look_down
* Contributors: Victor Lopez, narcismiguel, thomaspeyrucain

2.0.3 (2020-01-28)
------------------

2.0.2 (2018-11-16)
------------------
* Fix clang linking issues
* Contributors: Victor Lopez

2.0.1 (2018-04-20)
------------------

2.0.0 (2018-03-20)
------------------
* Homogenize package versions
* add main plane detector example
* add cylinder detector example
* add cylinder detector example
* add author
* reg. seg. example + dynamic_reconf to table_seg.
* first version
* Contributors: Jordi Pages, Victor Lopez

0.0.1 (2015-08-03)
------------------
