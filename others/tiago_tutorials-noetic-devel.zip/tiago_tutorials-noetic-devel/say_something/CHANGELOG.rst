^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package say_something
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.4 (2023-05-05)
------------------

2.0.3 (2020-01-28)
------------------

2.0.2 (2018-11-16)
------------------

2.0.1 (2018-04-20)
------------------

2.0.0 (2018-03-20)
------------------
* Homogenize package versions
* Merge branch 'more_tutorials' into 'master'
  More tutorials
  Added many more tutorials
  See merge request !1
* Add a TTS example
* Contributors: Sam Pfeiffer, Victor Lopez

0.0.1 (2015-08-03)
------------------
