^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tiago_trajectory_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.4 (2023-05-05)
------------------

2.0.3 (2020-01-28)
------------------
* Add SYSTEM to some include_directories
* Contributors: Victor Lopez

2.0.2 (2018-11-16)
------------------

2.0.1 (2018-04-20)
------------------

2.0.0 (2018-03-20)
------------------
* Homogenize package versions
* Merge pull request #7 from AleDF/traj_controller
  Change the velocity value to reach the waypoint
* Velocity last waypoint to zero
* Change velocities to have a smoother movement around waypoint
* Chenge the velocity value to reach the waypoint
* Merge pull request #6 from AleDF/traj_controller
  Add trajectory controller example
* Add trajectory controller example
* Contributors: AleDF, Jordi Pages, Victor Lopez

0.0.1 (2015-08-03)
------------------
